export const constJustifyContent = {
    flexStart: "flex-start",
    spaceBetween: "space-between",
    spaceEvenly: "space-evenly",
    flexEnd: "flex-end",
    center: "center"
};

export const constAlignItems = {
    stretch: "stretch",
    center: "center",
    flexStart: "flex-start",
    flexEnd: "flex-end",
    baseline: "baseline",
    initial: "initial",
    inherit: "inherit"
};
