import React, {useState, useEffect} from "react";
import A2Row from "../../../components/a2Row/a2Row";
import A2Text from "../../../components/a2Text/a2Text";

const WeatherForm = () => {
    return (
        <div>
            <A2Row>
                <A2Text>City</A2Text>

            </A2Row>
        </div>
    )
}

export default WeatherForm